open Yojson.Basic.Util

(** AF: A board is represented as having two tile fields, representing the
    start of each player's path, a [path_length] field represenitng the total
    length of each path, [partial_path_lengths], a 3-tuple representing
    the lengths of segments of the path, and a [piece_assoc] an association
    list containg pieces currently on the board as keys, with their tile
    locations as values. *)
type t = {
  p1_start: Tile.t; p2_start: Tile.t;
  path_length: int;
  partial_path_lengths: int * int * int;
  mutable piece_assoc: (Piece.t * Tile.t) list;
}

exception InvalidLength of int

(** [partial_path_lengths json] is a int 3-tuple created from [json], the first
    entry is the length of the start of each path, the second
    is the length of the middle path and the third entry is the 
    length of the end of each path. *)
let partial_path_lengths json =
  (* I think we could abstract this out a bit to another function? Just to 
     avoid repeated code.  *)
  let board_j = json |> member "board" in
  ((board_j |> member "start_length" |> to_int), 
   (board_j |> member "middle_length" |> to_int),
   (board_j |>member "end_length" |> to_int))

(** [create_start length next_tile] creates the start portion
    of a path with [length] tiles.
    The end of the path is a rosetta tile that has [next_tile] as it's 
    next tile *)
let create_start length next_tile =
  let rec helper len next =
    if len = 0 then next
    else begin 
      let new_tile = Tile.create_tile Normal None in
      Tile.link_next new_tile true next |>
      helper (len - 1)  

    end
  in

  let start_end = Tile.create_tile Rosetta None in
  Tile.link_next start_end true next_tile |>
  helper (length - 1)

(** [create_middle length st_len next1 next2] creates a middle path with 
    [length] tiles.

    The tile that lines up with the start path, which has length
    [st_len] is a rosetta tile, and the tile at the end of the middle
    path is a MidEnd tile that has next_p1 [next1] and next_p2 [next2]. *)
let create_middle length st_len next1 next2 = 
  let rec helper len st_len next =
    if len = 0 then next else begin
      (* I think we can just wrap the conditional around the length check so 
         we dont repeat the Tile...next and helper... lines *)
      if len = st_len then 
        let safe_space = Tile.create_tile Rosetta None in

        Tile.link_next safe_space true next |>
        helper (len-1) st_len
      else 
        let normal_tile = Tile.create_tile Normal None in 
        Tile.link_next normal_tile true next |>
        helper (len-1) st_len 

    end
  in
  let mid_end = Tile.create_tile MidEnd None in
  ignore (Tile.link_next mid_end true next1);
  Tile.link_next mid_end false next2 |>
  helper (length - 1) st_len

(** [create_end length] creates a end path of [length] tiles. 
    The last tile in the path is an End tile, and all the rest are normal
    tiles. *)
let create_end length = 
  let rec helper len next =
    if len = 0 then next
    else begin
      let normal_tile = Tile.create_tile Normal None  in 
      Tile.link_next normal_tile true next |>
      helper (len -1)
    end
  in
  Tile.create_tile End None |> helper (length - 1) 

let from_json json =
  let lengths = partial_path_lengths json in
  match lengths with
  | (s, m, e) -> begin 
      let end1 = create_end e in
      let end2 = create_end e in
      let middle = create_middle m s end1 end2 in

      {p1_start = create_start s middle; p2_start = create_start s middle;
       path_length = s + m + e;
       partial_path_lengths = lengths;
       piece_assoc = []
      }
    end

let get_partial_path_lengths board = board.partial_path_lengths

let path_start board is_p1 = 
  if is_p1 then board.p1_start else board.p2_start

let path_length board =
  board.path_length

let find_piece board piece =
  List.assoc_opt piece board.piece_assoc

let find_nth_tile start_tile is_p1 n =
  let rec find_n_helper tile counter =
    if counter = 0 then tile else 
      match Tile.next_tile tile is_p1 with
      | None -> InvalidLength n |> raise 
      | Some next_tile -> find_n_helper next_tile (counter - 1) 
  in
  find_n_helper start_tile n

let move_piece board piece n =
  let start_tile = find_piece board piece in
  match start_tile with
  | None -> ()
  | Some start_t -> begin
      let end_tile = find_nth_tile start_t (Piece.is_p1 piece) n in
      ignore (Tile.remove_piece start_t);
      board.piece_assoc <- List.remove_assoc piece board.piece_assoc;
      let old_piece = Tile.add_piece end_tile piece in
      match old_piece with 
      | None -> board.piece_assoc <- (piece, end_tile)::board.piece_assoc
      | Some op -> board.piece_assoc <- List.remove_assoc op board.piece_assoc;
        board.piece_assoc <- (piece, end_tile)::board.piece_assoc
    end

let add_piece_board board piece n = 
  let is_p1 = Piece.is_p1 piece in
  if n = 0 then () else begin
    let tile = find_nth_tile (path_start board is_p1) is_p1 (n -1 ) in
    ignore(Tile.add_piece tile piece);
    board.piece_assoc <- (piece, tile)::board.piece_assoc
  end















