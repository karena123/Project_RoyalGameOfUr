open Command 
open State

type difficulty = 
  | Random
  | Naive 
  | Smart

type move_data = {
  cmd: Command.t; 
  is_take: bool;
  is_rosetta: bool;
  is_score: bool;
  distance: int;
  distance_rosetta: int;
}

let is_valid_move st cmd = 
  try
    let _ = Rules.check_command st cmd in
    true
  with 
  | _ -> false

let min_dist_helper a x =
  match a with
  | None -> Some x
  | Some y -> Some(if x.distance_rosetta < y.distance_rosetta then x else y)

let rec dist_to_end tile accu = 
  match Tile.get_type tile with 
  | Tile.End -> accu 
  | _ -> begin 
      let tile_opt = Tile.next_tile tile false in 
      match tile_opt with 
      | None -> accu + 1
      | Some tile' -> dist_to_end tile' (accu + 1)
    end

let rec dist_to_rosetta_or_end tile accu = 
  match Tile.get_type tile with 
  | Tile.End ->  accu 
  | Tile.Rosetta -> accu
  | _ -> begin 
      let tile_opt = Tile.next_tile tile false in 
      match tile_opt with 
      | None -> accu + 1 
      | Some tile' -> dist_to_rosetta_or_end tile' (accu + 1) 
    end

let move_data_of_inputs cmd take rosetta score dist_end dist_rosetta = 
  {cmd= cmd; 
   is_take= take; 
   is_rosetta= rosetta; 
   is_score= score; 
   distance= dist_end; 
   distance_rosetta= dist_rosetta}

let piece_and_roll_of_st_and_cmd st cmd = 
  let p = match cmd with 
    | Move { piece= pi; roll= r} -> pi 
    | _ -> failwith "Invalidated precondition: cannot make data for a non-move command." 
  in
  let r = match st.roll with
    | None -> failwith "Impossible."
    | Some r -> r 
  in 
  p, r

let make_data st cmd = 
  let p, r = piece_and_roll_of_st_and_cmd st cmd
  in 
  let board = State.get_board st in 
  let is_p1 = false in 
  let org_tile, roll = match Board.find_piece board p with 
    | None -> Board.path_start board is_p1, r - 1
    | Some tile -> tile, r
  in 
  let dest_tile = Board.find_nth_tile org_tile is_p1 roll in 
  let dest_dist = dist_to_end dest_tile 0 in 
  let rosetta_dist = dist_to_rosetta_or_end dest_tile 0 in 
  match Tile.get_type dest_tile, Tile.get_piece dest_tile with 
  | Tile.Rosetta, None -> 
    move_data_of_inputs cmd false true false dest_dist rosetta_dist
  | Tile.Rosetta, Some _ -> 
    failwith "Invalidated Precondition: attempted to process a non-valid move (Rosetta)."
  | _, Some (P1 _) -> 
    move_data_of_inputs cmd true false false dest_dist rosetta_dist
  | _, Some (P2 _) -> 
    failwith "Invalidated Precondition: attempted to process a non-valid move (Self take)."
  | Tile.End, None ->     
    move_data_of_inputs cmd false false true dest_dist rosetta_dist
  | Tile.Normal, None | Tile.MidEnd , None  -> 
    move_data_of_inputs cmd false false false dest_dist rosetta_dist

let eval_lists diff move_datas scores takes rosettas min_to_rosetta first_legal = 
  match diff with 
  | Random -> begin 
      let n = Random.int (List.length move_datas) in
      let selected = List.nth move_datas n in 
      selected.cmd
    end 
  | Naive -> begin 
      match scores with 
      | score :: _ ->  score.cmd
      | [] -> begin 
          match takes with 
          | take :: _ ->  take.cmd
          | [] ->  first_legal
        end
    end 
  | Smart -> begin 
      match scores with 
      | score :: _ ->  score.cmd
      | [] -> begin 
          match takes with 
          | take :: _ -> take.cmd
          | [] -> begin 
              match rosettas with 
              | rosetta :: _ ->  rosetta.cmd 
              | [] -> min_to_rosetta.cmd 
            end
        end
    end 

let check_moves diff st = 
  let roll = match st.roll with
    | None -> failwith "Impossible."
    | Some r -> r 
  in 
  let pieces = st.pieces_p2 in (* the bot is always p2 *)
  let all_moves = Pass :: (List.map (fun p -> Move {piece= p; roll= roll}) pieces) 
  in 
  let valid_moves = List.filter (is_valid_move st) all_moves in 
  match valid_moves with 
  | [] -> failwith "ERROR: No valid moves."
  | Pass :: [] -> Pass
  | h :: _ -> begin 
      let move_datas = List.map (fun cmd -> make_data st cmd) valid_moves in 
      let scores = List.filter (fun data -> data.is_score) move_datas in 
      let takes = List.filter (fun data -> data.is_take) move_datas in 
      let rosettas = List.filter (fun data -> data.is_rosetta) move_datas in 
      let min_move = List.fold_left (min_dist_helper) None move_datas in
      let c = match min_move with 
        | None -> failwith "ERROR: No valid moves."
        | Some z -> z
      in 
      eval_lists diff move_datas scores takes rosettas c h 
    end


let create_command diff st = 
  match st.roll with
  | Some _ -> check_moves diff st
  | None -> Roll

