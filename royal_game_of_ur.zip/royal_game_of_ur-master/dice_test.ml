(** This is the Dice test file. There are a total of 5 passing tests.

    Parts of the system that were automatically tested by OUnit include: 
    checking that the roll of the dice using [Dice.roll d] would produce a 
    random integer within the appropriate range for the dice [d] provided. We 
    also checked that [Dice.sum lst] would return the sum of the elements in the 
    list of roll integers.

    Parts of the system that were manually tested include: None.

    Modules tested by OUnit: The Dice module.

    How test cases were developed: We used black box testing to check that the 
    randomized dice rolls are within the boundary ranges of the given dice, as 
    well as to check typical inputs and boundary cases for summing the list 
    elements.

    Why the testing approach demonstrates the correctness of the system: The 
    passing of the automatic OUnit tests indicates that rolling the dice only 
    returns integer roll numbers that are possible based on the dice 
    condiguration, and also shows that all roll lists are summed accurately. *)

open OUnit2
open Dice 

(** [string_of_int_list lst] is the string representation of the integer list
    [lst]. *)
let rec string_of_int_list = function 
  | [] -> ""
  | h::t -> string_of_int h ^ "; " ^ string_of_int_list t

(** [are_less_than x lst] is true if all values in [lst] are less than [x], 
    and false otherwise. *)
let are_less_than 
    (x : int) 
    (lst : int list) 
  : bool = 
  let rec helper result = function 
    | [] -> result 
    | h :: t -> helper (h < x && result) t
  in 
  helper true lst

(** [roll_prox_test name d] is the OUnit test with name [name] that checks 
    that a roll of [d] falls in between the range for that dice. *)
let roll_prox_test 
    (name:string) 
    (d : Dice.t) 
  : test = 
  name >:: (fun _ -> 
      let in_range = are_less_than (count d) (roll d) in
      assert_equal true in_range
        ~printer:string_of_bool)

(** [sum_test name lst expected_output] is the OUnit test with name [name] that 
    checks that a the sum of integers in [lst] is equal to [expected_output]. *)
let sum_test 
    (name:string) 
    (lst : int list) 
    (expected_output: int) 
  : test = 
  name >:: (fun _ -> 
      assert_equal expected_output (sum lst) ~printer:string_of_int)

(********************************************************************
   End helper functions.
 ********************************************************************)

let json1 = Yojson.Basic.from_file "./configs/config1.json" 
let dice1 = from_json json1

let json2 = Yojson.Basic.from_file "./configs/config2.json" 
let dice2 = from_json json2

(********************************************************************
   End Data.
 ********************************************************************)

let tests = [
  roll_prox_test "4 dice, 2 sides" dice1;
  roll_prox_test "999 dice, 50 sides" dice2;
  sum_test "empty list" [] 0;
  sum_test "non-zero integers" [1; 3; 5] 9;
  sum_test "zero-value integers" [0; 0; 0; 0] 0;
]