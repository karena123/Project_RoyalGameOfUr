type tile_type =
  | Rosetta
  | Normal
  | MidEnd
  | End

(** AF: A tile is represented by a record containing a tile_type
    [itle_type], and mutable fields [piece], representing the piece option
    on the tile, [next1] which representes the next tile on
    a path for any tile that is not a Midend, and the next tile
    one player 1's path if it is. [next2] is None unless it
    is a MidEnd tile, in which case it is an option of the next
    tile on Player 2's path. *)
type t = {tile_type: tile_type;
          mutable piece : Piece.t option; 
          mutable next1: t option;
          mutable next2: t option; }

let get_type tile =
  tile.tile_type

let get_piece tile =
  tile.piece

let next_tile tile is_p1 =
  match get_type tile with
  | End -> None 
  | Normal | Rosetta  -> tile.next1
  | _ -> begin 
      if is_p1 then tile.next1 else tile.next2
    end

let link_next current_tile is_p1 new_next =
  match get_type current_tile with
  | End -> current_tile
  | Normal | Rosetta-> current_tile.next1 <- Some new_next;
    current_tile
  | MidEnd -> begin
      if is_p1 then begin 
        current_tile.next1 <- Some new_next; 
        current_tile
      end
      else begin
        current_tile.next2 <- Some new_next;
        current_tile
      end
    end 

let is_rosetta tile =
  match get_type tile with
  | Rosetta -> true
  | _ -> false

let is_end tile =
  match get_type tile with
  | End -> true
  | _ -> false

let remove_piece tile =
  match get_piece tile with
  | None -> None
  | Some piece -> begin
      tile.piece <- None; 
      Some piece
    end

let add_piece tile piece = 
  let old_piece = tile.piece in
  tile.piece <- Some piece;
  old_piece

let create_tile tile_type piece_opt =
  {tile_type = tile_type; piece = piece_opt; next1 = None;
   next2 = None;}
