(** This is the Main test file. There are a total of 0 tests.

    Parts of the system that were automatically tested by OUnit include: None. 
    The Main module is of type unit and does not return an expected value 
    that can be compared to in an OUnit test.

    Parts of the system that were manually tested include: The Main module was 
    play-tested because it is of type unit and does not return an expected value 
    that can be compared to in an OUnit test. We manually tested valid and 
    invalid inputs to start the game, invalid commands that raised 
    Command.Invalid, illegal rules that raise Rules.Illegal, and valid inputs 
    to continue playing the game until a player wins.

    Modules tested by OUnit: Main module.

    How test cases were developed: Careful manual testing with play-testing.

    Why the testing approach demonstrates the correctness of the system: The 
    outcomes of the Main module cannot be compared in an OUnit test because 
    no outcome is returned. The manual testing shows when inputs are invalid 
    or illegal with specified messages, and shows when inputs are valid or 
    legal by continuing the game as expected.
*)