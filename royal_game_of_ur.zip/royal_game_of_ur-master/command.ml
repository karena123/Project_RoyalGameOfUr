open ANSITerminal
open Yojson
type t = 
  | Roll 
  | Move of {piece: Piece.t; roll: int}
  | Pass (* No legal moves *)
  | Quit
  | Start of string

exception Invalid
exception Empty 

(** Precondition: Roll is None if no roll has been made by
    the current player*)
let parse is_p1 roll str = 
  let cmd = str |> String.lowercase_ascii |> String.split_on_char ' ' 
            |> List.filter (fun x -> x <> "") 
  in

  match cmd with
  | [] -> raise Empty
  | "roll" :: [] | "r" :: [] -> Roll
  | "pass" :: [] | "p" :: [] -> Pass
  | "quit" :: [] | "q" :: [] -> Quit
  | "start" :: json :: [] -> Start json
  | "move" :: number :: [] | "m" :: number :: [] -> begin 
      match roll with 
      | None -> raise Invalid
      | Some r ->
        try Move {piece = Piece.make_piece is_p1 (int_of_string number);
                  roll = r}
        with Failure _ -> raise Invalid
    end
  | number :: [] -> begin match roll with 
      | None -> raise Invalid
      | Some r ->
        try Move {piece = Piece.make_piece is_p1 (int_of_string number);
                  roll = r}
        with Failure _ -> raise Invalid end
  | _ -> raise Invalid

