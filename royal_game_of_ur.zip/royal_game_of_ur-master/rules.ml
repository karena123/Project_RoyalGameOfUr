exception Illegal of string

open Command

let check_roll st cmd = 
  match State.get_roll st with 
  | None -> cmd 
  | Some _ -> raise (Illegal "The dice has already been rolled this turn.")

let check_take dest_tile is_p1 cmd = 
  match Tile.get_type dest_tile, Tile.get_piece dest_tile with 
  | Tile.Rosetta, Some _ -> raise (Illegal "You cannot move a piece to a Rosetta with an existing piece.") 
  | _, Some existing -> begin
      if Piece.is_p1 existing = is_p1 then raise (Illegal "You cannot take your own pieces.")
      else cmd
    end
  | _ -> cmd

let check_move st cmd = 
  match State.get_roll st with 
  | None -> raise (Illegal "You cannot move a piece before rolling.")
  | Some n -> 
    begin
      match cmd with 
      | Move {piece= p; roll= r} -> 
        if r=0 then raise (Illegal "You cannot move a piece 0 squares.") 
        else begin
          let board = State.get_board st in 
          let turn = State.get_turn st in 
          let is_p1 = turn = State.P1 in 
          let org_tile, roll = match Board.find_piece board p with 
            | None -> Board.path_start board is_p1, r-1
            | Some tile -> tile, r
          in 
          try let dest_tile = Board.find_nth_tile org_tile is_p1 roll in 
            check_take dest_tile is_p1 cmd
          with Board.InvalidLength _ -> raise (Illegal "You have tried to move the piece too many spaces or this piece
          has already been counted.")
        end
      | _ -> failwith "wrong check."
    end

let check_pass st cmd = 
  let turn = State.get_turn st in 
  let is_p1 = match turn with 
    | P1 -> true 
    | P2 -> false
  in 
  let pieces = if is_p1 then st.pieces_p1 else st.pieces_p2 in 
  let roll = match State.get_roll st with 
    | None -> raise (Illegal "You cannot pass before rolling.") 
    | Some n -> n
  in

  let rec helper pieces_remain = 
    match pieces_remain with 
    | [] -> cmd 
    | h :: t -> begin
        try let _ = check_move st (Move {piece=h; roll=roll}) in
          raise (Illegal "You cannot pass whilst there are still valid moves.")
        with Illegal "You cannot move a piece to a Rosetta with an existing piece." 
           | Illegal "You cannot take your own pieces." 
           | Illegal "You have tried to move the piece too many spaces."
           | Illegal "You cannot move a piece 0 squares." 
           | Illegal "You have tried to move the piece too many spaces or this piece
          has already been counted." -> helper t
      end
  in helper pieces

let check_start st cmd str = 
  (* Check to see file exists and that it is of proper format. *)
  if "./configs/" ^ str |> Sys.file_exists then cmd
  else raise (Illegal "That file does not exist.")

let check_command st cmd = 
  match cmd with 
  | Roll -> check_roll st cmd
  | Move {piece= p; roll= r} -> check_move st cmd
  | Pass -> check_pass st cmd
  | Quit -> cmd
  | Start str -> check_start st cmd str