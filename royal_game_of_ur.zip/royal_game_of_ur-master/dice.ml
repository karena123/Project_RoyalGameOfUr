open Yojson.Basic.Util

type t = {
  n : int;
  sides: int;
}

let rec string_of_int_list acc = function 
  | [] -> acc 
  | h :: t -> string_of_int_list (string_of_int h ^ acc) t


(** HELPER FUNCTIONS *)
let rec make_list n x = 
  if n = 0 then [] 
  else x :: make_list (n - 1) x

(** MAIN FUNCTIONS *)
let from_json j = 
  let dice_ref = j |> member "dice" in
  {
    n = dice_ref |> member "n" |> to_int;
    sides = dice_ref |> member "sides" |> to_int;
  }

let roll d = 
  Random.self_init () ;
  make_list d.n d.sides |> List.map (fun x -> Random.int x)

let sum lst = 
  List.fold_left ( + ) 0 lst

let sides d = 
  d.sides 

let count d = 
  d.n
