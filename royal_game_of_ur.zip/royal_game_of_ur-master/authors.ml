let hours_worked = 72
