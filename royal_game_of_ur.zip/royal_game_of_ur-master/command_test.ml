(** This is the Command test file. There are a total of 24 passing tests.

    Parts of the system that were automatically tested by OUnit include: 
    checking that all invalid inputs of roll, move, pass, quit, start, and no 
    command cannot be parsed and returned as commands, while all valid inputs of 
    roll, move, pass, quit, and start can be parsed and returned as commands.

    How test cases were developed: We used black box testing to test the basic 
    possible inputs that are valid commands, as well as those that are invalid.

    Why the testing approach demonstrates the correctness of the system: In 
    general, this testing approach clearly indicates how invalid inputs by 
    the player are not parsed, and therfore raises a Command.Invalid, while 
    valid inputs are parsed, and therefore, returns the appropriate commands 
    made by the player. Since all 24 tests pass, it suggests that valid and 
    invalid command inputs are parsed appropriately. *)

open OUnit2
open Command

(** [parse_test name is_p1 roll str expected_cmd] creates an OUnit2 test [name]
    that tests that [str], when parsed given [is_p1] and [roll] is 
    the same command as the expected output. *)
let parse_test name is_p1 roll str expected_cmd =
  name >:: (fun _ -> 
      assert_equal expected_cmd (parse is_p1 (Some roll) str))

(** [parse_raise name is_p1 roll str expected_raise] creates an OUnit2
    test that tests that [parse] [is_p1] [roll] [str] raises
    [expected_raise]. *)
let parse_raise name is_p1 roll str expected_raise =
  name >:: (fun _ ->
      assert_raises expected_raise (fun () -> parse is_p1 (Some roll) str))

let tests = [
  parse_raise "empty string" true ~-1 "" Empty;
  parse_raise "white space" false 5 " " Empty;
  parse_raise "wrong command" true 2 "go sd" Invalid;
  parse_raise "bad roll 1" false 2 "roll yep" Invalid;
  parse_raise "bad roll 2" false 8 "roll       j" Invalid;
  parse_raise "bad start 1" true 9 "start jjjj dd" Invalid;
  parse_raise "bad start 2" false 10 "start " Invalid;
  parse_raise "bad quit" false 10 "quit gf" Invalid;
  parse_raise "bad pass" true 0 "pass 33" Invalid;
  parse_raise "bad move" true ~-2 "move yes" Invalid;
  parse_raise "bad move" false 8 "move 3 ioi" Invalid;

  parse_test "good roll 1" false 2 "roll" Roll;
  parse_test "good roll 2" true 88 "Roll    " Roll;
  parse_test "good roll r" true 88 "r    " Roll;
  parse_test "good quit 1" true 9 "quit" Quit;
  parse_test "good quit 2" false 2 "QUIT    " Quit;
  parse_test "good quit q" false 2 "q    " Quit;
  parse_test "good pass" true 9 "Pass   " Pass;
  parse_test "good pass p" true 9 "p   " Pass;
  parse_test "good start " true 9 "stArt memem   " (Start "memem");

  parse_test "move good 1" true 10 "MOVE 5" (Move 
                                               {piece = P1 5; roll = 10});
  parse_test "move good 2" false ~-2 "MOVE 8" (Move 
                                                 {piece = P2 8; roll = ~-2});
  parse_test "move good m" true 10 "m 5" (Move 
                                            {piece = P1 5; roll = 10});
  parse_test "move good num" false ~-2 "8" (Move 
                                              {piece = P2 8; roll = ~-2});
]
