# Install Directions

# Instructions to use X11 graphics:

Step up for Windows:

1. Install a program that can display X11 graphics, such as XMing.
2. Open and run said program and set the display to '0' and do not set it
   to display any given client.
3. In the terminal type "$ export DISPLAY=:0" and you should be
   able to run the graphics.

Steps for Mac:

1. Install Apple Devlopers Tools for easy, automatic use of graphics.
   Alternatively use a program for displaying X11 windows such as Quartz and
   follow the same steps as the windows install.

===========================================================================
Remaining Installation:

1. Install the required dependencies:
   `opam install ounit2 yojson ANSITerminal graphics`
2. In the command line, run `make build`.
3. To run tests, run `make test`.
4. To play the game, run `make play`.
5. Select the settings you want, such as whether or not you want to play against
   a bot or what board you want play on.
