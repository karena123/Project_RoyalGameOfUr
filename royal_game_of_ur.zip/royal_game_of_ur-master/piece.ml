(** A [piece] carries an int representing the number of the piece
    as well as whether or not the piece belongs to player 1 or player 2. *)

type t =
  |P1 of int
  |P2 of int

exception InvalidNum of int

let is_p1 = function
  | P1 x -> true
  | P2 x -> false

(* should we call this just [num] so its a bit more functional-esque? *)
let get_num = function
  | P1 x -> x
  | P2 x -> x

let make_piece is_p1 num =
  if num <= 0 then InvalidNum num |> raise else 
  if is_p1 then P1 num else P2 num
