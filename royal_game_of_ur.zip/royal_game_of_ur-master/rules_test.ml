(** This is the Rules test file. There are a total of 8 passing tests.

    Parts of the system that were automatically tested by OUnit include: all 
    cases where checking the player's command against the game rules result in 
    Illegal arguments being raised (Rules.Illegal). This includes the case when 
    the initial roll in the initial starting game state passes, as well as the 
    cases where illegal commands are inputted, such as rolling again, 
    moving before rolling, moving 0 squares, moving too many spaces, passing 
    before rolling, passing even with valid moves available, and starting with 
    an invalid json file.

    Parts of the system that were manually tested include: checking that legal 
    inputs passed the game rules. Legal commands of roll, move, pass, quit, and 
    start were play-tested to ensure that Rules.Illegal was not raised and that 
    the game continued after each legal command input. This is necessary since 
    legal moves do not produce comparable outputs.

    How test cases were developed: We used glass box testing to ensure that all 
    possible outcomes of illegal commands were covered.

    Why the testing approach demonstrates the correctness of the system: This 
    testing file with glass-box testing approach accurately covers the possible 
    branches of cases where Rules.Illegal can be raised from different illegal 
    commands for roll, move, pass, and start. Legal moves for roll, move, pass, 
    quit, and start were play-tested because they simply pass the game rules 
    and do not produce outputs that can be compared with expected outputs, 
    unlike illegal commands that raise error messages. Thus, the passing of 
    these tests demonstrate how the system prevents all illegal commands from 
    being passed and allows all legal commands to pass to continue the game.
*)

open OUnit2
open Command
open Rules 
open Board
open Piece
open Dice

let rule_test name st cmd expected_pass expected_msg= 
  name >:: (fun _ -> 
      if expected_pass then assert_equal cmd (check_command st cmd) else 
        assert_raises (Illegal expected_msg) (fun () -> check_command st cmd) 
    )

let json = Yojson.Basic.from_file "./configs/config1.json"
let st1 = State.init_from_json json
let board = Board.from_json json
let dice = Dice.from_json json
let p1_pieces = [Piece.make_piece true 1; Piece.make_piece true 2; 
                 Piece.make_piece true 3;]
let p2_pieces = [Piece.make_piece false 1; Piece.make_piece false 2;
                 Piece.make_piece false 3;]
let st2 = State.create_state board 0 0 P1 p1_pieces p2_pieces dice
let st3 = State.update_state Roll st2
let st4 = State.update_state (Move {piece = P1 1; roll = 2}) st3

let tests = 
  [
    rule_test "Initial state, roll should pass" st1 Roll true "";
    rule_test "Dice already rolled" st3 Roll 
      false "The dice has already been rolled this turn.";
    rule_test "Cannot move before rolling" st1 (Move {piece = P1 1; roll = 2}) 
      false "You cannot move a piece before rolling.";
    rule_test "Cannot move 0" st3(Move {piece = P1 1; roll = 0}) 
      false "You cannot move a piece 0 squares.";
    (* rule_test "Cannot move to a Rosetta with existing piece" st4 
       (Move {piece = P1 2; roll = 2}) 
       false "You cannot move a piece to a Rosetta with an existing piece."; *)
    (* rule_test "Cannot take own piece" st4
       (Move {piece = P1 2; roll = 2}) 
       false "You cannot take your own pieces."; *)
    rule_test "Cannot move too many spaces" st3 (Move {piece = P1 1; roll = 15}) 
      false "You have tried to move the piece too many spaces or this piece
          has already been counted.";
    rule_test "Cannot pass before rolling" st1 
      Pass false "You cannot pass before rolling.";
    rule_test "Cannot pass with valid moves" st3 
      Pass false "You cannot pass whilst there are still valid moves.";
    rule_test "Start file doesn't exit" st1 
      (Start "none.json") false "That file does not exist.";
  ]


