open Graphics

(**`[dir] is the direction of an arrow in a given tile. *)

let build_board state = 
  let board = State.get_board state in

  let start_length, mid_length, end_length =
    match Board.get_partial_path_lengths board with
    | (s,m,e) -> s, m, e 
  in

  let tile_matrix = Array.make_matrix 3 mid_length (None) in
  (** [follow_path_end] adds a current tile_opt [tile_opt]
      to the tile option matrix to col [col]. If [is_p1] is true
      it is added to row 0, otherwise it is added to row 2. Essentially
      it follows the end of a player's path, adding tiles to
      the tile matrix from right to left.  *)
  let rec follow_path_end tile_opt is_p1 col =
    match tile_opt with 
    | None -> () 
    | Some tile -> if is_p1 then begin tile_matrix.(0).(col) <- Some tile;
        follow_path_end (Tile.next_tile tile is_p1) is_p1 (col -1) end 

      else begin tile_matrix.(2).(col) <- Some tile;
        follow_path_end (Tile.next_tile tile is_p1) is_p1 (col -1) end
  in
  (** [follow_path_middle] adds a current tile_opt [tile_opt]
      to the tile option matrix to col [col]. [is_p1] is kept
      track of for follow_path_end, and has no effect since all
      tiles are added to row 1. Essentially
      it follows the middle of a player's path, adding tiles to
      the tile matrix from left to right.  *)
  let rec follow_path_middle tile_opt is_p1 col = 
    match tile_opt with 
    | None -> ()
    | Some tile -> begin 
        tile_matrix.(1).(col) <- Some tile;
        if col = mid_length - 1 then  
          follow_path_end (Tile.next_tile tile is_p1) is_p1 col
        else 
          follow_path_middle (Tile.next_tile tile is_p1) is_p1 (col + 1) 
      end
  in 
  (** [follow_path_start] adds a current tile_opt [tile_opt]
      to the tile option matrix to col [col]. If [is_p1] is true
      it is added to row 0, otherwise it is added to row 2. Essentially
      it follows the start of a player's path, adding tiles to
      the tile matrix from right to left.  *)
  let rec follow_path_start tile_opt is_p1 col = 
    match tile_opt with 
    | None -> () 
    | Some tile -> 
      let r = if is_p1 then 0 else 2 in
      tile_matrix.(r).(col) <- Some tile;
      if col = 0 then 
        follow_path_middle (Tile.next_tile tile is_p1) is_p1 col
      else 
        follow_path_start (Tile.next_tile tile is_p1) is_p1 (col -1)
  in 
  follow_path_start (Some (Board.path_start board true)) true 
    (start_length -1);
  follow_path_start (Some (Board.path_start board false)) false 
    (start_length -1);
  tile_matrix


let redraw scale state = 
  let start_length,mid_length,end_length = 
    State.get_board state |> Board.get_partial_path_lengths
  in 
  if mid_length < 8 then (Graphics.resize_window (8 * 100 + 100) 550;)
  else Graphics.resize_window (mid_length * 100 + 100) 550;
  let size_xc = Graphics.size_x () in 
  let size_yc = Graphics.size_y () in 
  Graphics.set_color black;
  Graphics.fill_rect 0 0 size_xc size_yc ;
  Graphics.set_color (Graphics.rgb 52 101 77);(*Poker Board Color*)
  Graphics.fill_rect 5 5 (size_xc-10) (size_yc-10) ;

  let tile_matrix = build_board state in

  let draw_tile tile_opt row col scale = 
    (** [draw_piece piece_opt r c sc] draws a piece if [piece_opt] is not
        none. The piece is drawn in a tile with row [r], col [c] and
        scale [sc]. *)
    let draw_piece (piece_opt: Piece.t option) r c sc =
      match piece_opt with 
      | None -> ()
      | Some piece -> begin
          let p_color = if Piece.is_p1 piece then Graphics.blue
            else Graphics.red in 
          Graphics.( 
            set_color p_color;
            fill_circle ((c*10 + 10) * sc)
              ((r*10 + 20 ) * sc) (2* sc);
            set_text_size (sc*1000);
            set_color white;
            let num = Piece.get_num piece |> string_of_int in
            moveto ((c*10 +10) * sc) ((r*10 + 20) *sc);
            draw_string num
          )
        end

    in

    (**[draw_normal r c sc], draws a normal tile at row [r] and col [c]
        with scale [sc]. *)
    let draw_normal r c sc = 
      Graphics.(
        rgb 48 38 22 |> set_color; (*Dark Wood*)
        fill_rect ((c *10 + 5) * sc) ((r*10 + 15) * sc)
          ( sc * 10) (sc * 10);
        rgb 202 164 114 |> set_color; (*Light Wood*)
        fill_rect ((c*10 + 6)* sc) 
          ((r*10 + 16) * sc)) (sc * 8) (sc * 8);
      set_color black;
      if c = start_length -1 && r <> 1 then begin 
        moveto ((c *10 + 7) * sc) ((r*10 + 18) * sc);
        draw_string "Start" 
      end
      else begin 
        if c = (mid_length) - end_length && r <> 1 then (
          moveto ((c *10 + 7) * sc) ((r*10 + 18) * sc);
          draw_string "End" )
        else ()
      end;
    in
    (** [draw_dir r c sc] draws direction arrows in tiles depending
              on their row [r] and col [c] and scale [sc]. *)
    let draw_dir r c sc =
      set_color black;
      let dir_char = 
        match r, c with 
        | 2, 0 -> "\\/"
        | 0, 0 -> "^"
        | 1, x -> if x <> mid_length -1 then ">" 
          else  begin 
            moveto ((c *10 + 10) * sc) ((r*10 + 20) * sc);
            draw_string "^";
            "\\/"
          end
        | _ -> "<"
      in
      moveto ((c *10 + 10) * sc) ((r*10 + 18) * sc);
      draw_string dir_char
    in

    (** [draw_rosetta r c is_rosetta piece_opt sc] draws a normal
        tile and if [is_rosetta] is false. Otherwise it draws
        a rosetta tile. The tile is at row [r] and col [c] and scale [sc]. 
        Then it will call draw_piece with [piece_opt]. *)

    let draw_rosetta r c is_rosetta piece_opt sc = 
      if not is_rosetta then (draw_normal r c sc; draw_piece piece_opt r c sc;
                              draw_dir r c sc) 
      else begin
        draw_normal r c sc;
        Graphics.(
          rgb 139 0 139 |> set_color; (*Magenta*)
          fill_circle ((c*10 + 10) * sc) ((r*10 + 20) * sc) (3 * sc);
          rgb 255 102 0 |> set_color; (*Orange*)
          fill_circle ((c*10 + 10) * sc) 
            ((r*10 + 20) * sc) (1 * sc);
          draw_piece piece_opt r c sc;
          draw_dir r c sc
        )
      end
    in
    match tile_opt with 
    | None -> ()
    | Some tile -> begin 
        match Tile.get_type tile with 
        | Rosetta ->  draw_rosetta row col true (Tile.get_piece tile) scale 
        | _ -> draw_rosetta row col false (Tile.get_piece tile) scale 
      end
  in
  Array.iteri (fun r row -> Array.iteri 
                  (fun c tile -> draw_tile tile r c scale) row) tile_matrix;

  Graphics.(
    black |> set_color;
    fill_rect 0 0 size_xc 130;
    fill_rect 0 500 size_xc 50;
    rgb 196 202 206 |> set_color; (*Silver*)
    fill_rect 5 5 (size_xc - 10 ) 120;
    fill_rect 5 505 (size_xc - 10) 40;
    black |> set_color;
    set_text_size 5;
    moveto (size_x () / 2 - 45) 100;

    let curr_turn = 
      match State.get_turn state with
      | P1 -> set_color blue; "Player 1" 
      | P2 -> set_color red; "Player 2"

    in

    draw_string ("Current Turn: " ^ curr_turn);
    moveto (size_xc / 2 - 310) 80;
    set_color blue;
    draw_string ("P1: " ^ (string_of_int (State.score_of_P1 state)));
    moveto (size_xc /2 - 390) 50;

    let p1_pieces = 
      State.get_P1_pieces state |> List.rev |>
      Ascii_printer.string_of_list Ascii_printer.string_of_piece "" 

    in

    draw_string ("P1 Pieces in hand: " ^ p1_pieces);
    moveto (size_xc / 2 + 250) 80;
    set_color red;
    draw_string ("P2: " ^ (string_of_int (State.score_of_P2 state)));

    let p2_pieces = 
      State.get_P2_pieces state |> List.rev |>
      Ascii_printer.string_of_list Ascii_printer.string_of_piece "" 

    in

    moveto (size_xc /2 + 150) 50;
    draw_string ("P2 Pieces in hand: " ^ p2_pieces);
    moveto (size_xc / 2 - 35) 60;

    let roll = match State.get_roll state with
      | None -> "None"
      | Some r -> string_of_int r

    in

    set_color black;
    draw_string ("Current Roll:  " ^ roll);
    moveto (size_xc / 2 - 425) 20;
    draw_string 
      ("Controls: q -> quit | p -> pass (Which must be done if no moves can be made) | r -> roll | Number Key (1,2,...) -> moves numbered piece"
      )
  )

let init_window state =
  Graphics.open_graph "";
  Graphics.set_window_title "The Royal Game of Ur";
  redraw 10 state

let declare_winner winner = 
  let color = if winner = "Player 1" then Graphics.blue else Graphics.red

  in

  Graphics.(
    set_color color;
    fill_rect 0 200 (size_x ()) 200;
    moveto (size_x () / 2 - 35) 300;
    set_color white;
    draw_string ("The Winner is: " ^ winner)
  );
  Unix.sleep 100

let read_actions () =
  let key_press = Graphics.wait_next_event [Graphics.Key_pressed] in 

  match key_press.key with
  | 'q' | 'Q' ->  "q"
  | 'r' | 'R' -> "r"
  | 'p' | 'P' -> "p"
  | '1' -> "m 1"
  | '2' -> "m 2"
  | '3' -> "m 3"
  | '4' -> "m 4"
  | '5' -> "m 5"
  | '6' -> "m 6"
  | '7' -> "m 7"
  | '8' -> "m 8"
  | '9' -> "m 9"
  | _ -> "gg"

let display_msg state msg = 
  let size_xf = Graphics.size_x () in
  Graphics.(
    set_color black;
    fill_rect 0 500 size_xf 50;
    rgb 196 202 206 |> set_color; (*Silver*)
    fill_rect 5 505 (size_xf - 5 ) 45;
    set_color black;
    moveto (size_xf / 2 - 125) 520;
    draw_string msg;
  )

let init_game () = 
  Graphics.open_graph "";
  Graphics.set_window_title "The Royal Game of Ur";
  Graphics.resize_window (7 * 100 + 100) 550;
  let size_xc = Graphics.size_x () in 
  let size_yc = Graphics.size_y () in 
  Graphics.(
    set_color black;
    fill_rect 0 0 size_xc size_yc ;
    set_color (Graphics.rgb 196 202 206);
    fill_rect 5 5 (size_xc- 10) (size_yc - 10);

  )













