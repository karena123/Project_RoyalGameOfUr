(** This is the main test file. There are a total of 69 passing tests.

    Due to the breadth of the system, we have split up testing into multiple
    files. There are additional Test Plans for each module's test file 
    detailed at the top of their respective test documents (i.e. 
    [rules_test.ml], [command_test.ml], etc.) for less confusion and for 
    greater readability.

    Parts of the system that were manually tested include: Main, Display, AI.

    Modules tested by OUnit: State, Piece, Tile, Board, Command, Dice, Rules.

    How test cases were developed: For modules that depend on game states, 
    we developed black box tests by creating game states and asserting on final
    game states after a given operation. More detail can be found about the 
    way tests were developed in the individual files.

    In general, the use of automatic black box testing for our core 
    components and game logic (State, Piece, Tile, ..., etc) means we can 
    reliably develop our higher-level modules such as AI or Rules. Then, with 
    a mix of OUnit testing and intensive play-testing, we can confidently say
    we have tested the vast majority of possible game states and actions (since
    The Royal Game of Ur is inherently a very simple game with a limited 
    number of actions available per turn). 
*)

let state_tests = State_test.tests

let tile_tests = Piece_tile_board_test.tile_tests

let piece_tests = Piece_tile_board_test.piece_tests

let board_tests = Piece_tile_board_test.board_tests

let command_tests = Command_test.tests

let dice_tests = Dice_test.tests

let rules_tests = Rules_test.tests

open OUnit2

let suite = 
  "Royal Game of Ur test suite" >::: List.flatten [
    piece_tests;
    tile_tests;
    board_tests;
    state_tests;
    command_tests;
    dice_tests;
    rules_tests;
  ]

let _ = run_test_tt_main suite
