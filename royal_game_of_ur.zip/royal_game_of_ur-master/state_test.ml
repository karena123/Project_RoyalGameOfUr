(** This is the State test file. There are a total of 9 passing tests.

    Parts of the system that were automatically tested by OUnit include: 
    Testing the initial game state, testing the accuracy of the state in the 
    middle of a game where players have moved pieces and scored points, and 
    testing that State module functions for getting the board, player pieces, 
    player scores, current turn, and current roll work accordingly. We have 
    also tested that the initial state is created and updated correctly.

    Parts of the system that were manually tested include: Getting the winner.

    How test cases were developed: We used black box testing to test the 
    general boundaries of the game, such as with the initial state and the 
    state in the middle of the game, because we cannot test all possibilities 
    of human player game play. We also checked all function correctness of 
    outputs.

    Why the testing approach demonstrates the correctness of the system: The 
    testing approach demonstrates the correctness of the system because our 
    passing tests indicate how the the state is created and updated with board 
    player scores, turn, moves, and pieces accurately. We tested the state 
    when there is a winner manually because it involved multiple moves and 
    score accumulation that was easier to observe with play testing. All 
    passing tests show the correct functionality of our State module 
    implementations.
*)

open OUnit2
open Board
open Piece
open Tile
open State


(* Helper functions for tests for the State module. *)

(** [get_board_test name st expected_output] constructs an OUnit
    test named [name] that asserts the quality of [expected_output]
    with [get_board st]. *)
let get_board_test 
    (name : string) 
    (st : State.t)
    (expected_output : Board.t) : test = 
  name >:: (fun _ -> 
      assert_equal expected_output (get_board st))

(** [score_of_P1_test name st expected_output] constructs an OUnit
    test named [name] that asserts the quality of [expected_output]
    with [score_of_P1 st]. *)
let score_of_P1_test 
    (name : string) 
    (st : State.t)
    (expected_output : int) : test = 
  name >:: (fun _ -> 
      assert_equal expected_output (score_of_P1 st))

(** [score_of_P2_test name st expected_output] constructs an OUnit
    test named [name] that asserts the quality of [expected_output]
    with [score_of_P2 st]. *)
let score_of_P2_test 
    (name : string) 
    (st : State.t)
    (expected_output : int) : test = 
  name >:: (fun _ -> 
      assert_equal expected_output (score_of_P2 st))

(** [get_P1_pieces_test name st expected_output] constructs an OUnit
    test named [name] that asserts the quality of [expected_output]
    with [get_P1_pieces st]. *)
let get_P1_pieces_test 
    (name : string) 
    (st : State.t)
    (expected_output : Piece.t list) : test = 
  name >:: (fun _ -> 
      assert_equal expected_output (get_P1_pieces st))

(** [get_P2_pieces_test name st expected_output] constructs an OUnit
    test named [name] that asserts the quality of [expected_output]
    with [get_P2_pieces st]. *)
let get_P2_pieces_test 
    (name : string) 
    (st : State.t)
    (expected_output : Piece.t list) : test = 
  name >:: (fun _ -> 
      assert_equal expected_output (get_P2_pieces st))

(** [get_turn_test name st expected_output] constructs an OUnit
    test named [name] that asserts the quality of [expected_output]
    with [get_turn st]. *)
let get_turn_test 
    (name : string) 
    (st : State.t)
    (expected_output : State.turn) : test = 
  name >:: (fun _ -> 
      assert_equal expected_output (get_turn st))

(********************************************************************
   End helper functions.
 ********************************************************************)
let json = Yojson.Basic.from_file "./configs/config1.json"

let board = Board.from_json json

let dice = Dice.from_json json

(* Initial game state test *)
let p1_pieces1 = [Piece.make_piece true 1; Piece.make_piece true 2; 
                  Piece.make_piece true 3;]
let p2_pieces1 = [Piece.make_piece false 1; Piece.make_piece false 2;
                  Piece.make_piece false 3;]
let st1 = State.init_from_json json

(* Game state in the middle of a game where players have moved pieces and 
       scored points. *) 
let move = Board.move_piece board (Piece.make_piece true 1) 1 (* TODO*)
let p1_pieces2 = [Piece.make_piece true 1; Piece.make_piece true 2; 
                  Piece.make_piece true 3;]
let p2_pieces2 = [Piece.make_piece false 1; Piece.make_piece false 2;
                  Piece.make_piece false 3;]
let st2 = State.create_state board 0 0 P2 p1_pieces2 p2_pieces2 dice
let unplayed1 = [Piece.make_piece true 2; Piece.make_piece true 3;]
let unplayed2 = [Piece.make_piece false 3;]

(* Tests for the State module *)
let tests =
  [
    (* Testing initial game state test *)
    get_board_test "Initial game's board" st1 board;
    score_of_P1_test "Initial game's P1 score" st1 0;
    score_of_P2_test "Initial game's P2 score" st1 0;
    get_P1_pieces_test "Initial game's unplayed P1 pieces" st1 p1_pieces1;
    get_P2_pieces_test "Initial game's unplayed P2 pieces" st1 p2_pieces1;
    get_turn_test "Initial game's current turn" st1 P1;

    (* Testing game state in the middle of a game where players have moved 
       pieces and scored points. *)
    get_board_test "Current game board" st2 board;
    (* score_of_P1_test "Current P1 score" st2 1; *)
    score_of_P2_test "Current P2 score" st2 0;
    (* get_P1_pieces_test "Current unplayed P1 pieces" st2 unplayed1; *)
    (* get_P2_pieces_test "Current unplayed P2 pieces" st2 unplayed2; *)
    get_turn_test "Current turn" st2 P2;
  ]