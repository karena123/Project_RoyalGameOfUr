open Ascii_printer
open Ai

(* [read_and_exc st input is_bot display_on] takes in a command input [input],
   and checks the 
   command in [Command.parse]. If the command can be parsed and is valid, 
   then checks the command in [Rules.check_command] to see if the command 
   is legal. If the command passes both calls without raising an exception, 
   then passes the command [cmd] into [State.update cmd st] to update the game 
   state. Then, [read_and exc] prompts the player for a new command, and 
   calls itself recursively, inputting the new state and new command.

   [read_and_exc] also catches Command.Invalid and Rules.Illegal and prints an 
   error message for both cases, then asks the player for a new command input 
   and calls itself recursively with the old game state and new command.

   [bot_on] when true, makes it so that player 2's turn is run by a bot,
   otherwise it will prompt anothe rplayer to act. 
   [display_on] when true, operates thae X11 window display. When 
   false ASCII graphics are instead utilized in the termnial.

   [bot_difficulty] is the difficulty of the bot, it is set to Random
   if the bot is not in use. *)

let rec read_and_exc st input bot_on bot_difficulty display_on =
  (* If no exceptions are raised, then execute the player's command. *)
  try 
    (* [is_p1] returns a bool for whether the current turn is player 1 [P1] or 
       player 2 [P2]. If it is player 1, then returns true. Otherwise, returns 
       false. *)
    let is_p1 = begin
      if State.P1 = State.get_turn st then true
      else false
    end in

    let cmd = 
      if not bot_on || is_p1 then 
        (input |> Command.parse is_p1 (State.get_roll st) 
         |> Rules.check_command st)  
      else 
        (* BOT RETURNS A COMMAND *)
        create_command bot_difficulty st
    in
    let new_st = State.update_state cmd st in

    match new_st.winner with 
    | Some str -> 
      begin 
        (*Graphics Display*)
        if display_on then begin
          Display.declare_winner str;
          exit 0; 
        end 
        (*Terminal Mode*)
        else 
          begin
            print_string "\n";
            Ascii_printer.print_state new_st; 
            print_string (str ^ " has won!"); 
            Display.declare_winner str;
            exit 0; 
          end
      end
    | None -> 
      begin
        (* Updates state and prompts player for new command. *)
        (*Graphics Display*)
        if display_on then begin 
          Display.redraw 10 new_st;
          let next_cmd = Display.read_actions () in 
          read_and_exc new_st next_cmd bot_on bot_difficulty display_on
        end 
        (*Terminal Mode*)
        else begin
          print_string "\n";
          Ascii_printer.print_state new_st;
          print_endline "Please enter next command.\n";
          print_string  "> ";
          match read_line () with
          | exception End_of_file -> ()
          | next_cmd -> read_and_exc new_st next_cmd bot_on bot_difficulty 
                          display_on
        end
      end

  with

  (* Reports error in command input to the player, and prompts for a new 
     command. *)
  | Command.Invalid | Command.Empty -> begin
      (*Graphics Display*)
      if display_on then begin 
        let next_cmd = Display.read_actions () in 
        read_and_exc st next_cmd bot_on bot_difficulty display_on  end 
      (*Terminal Mode*)
      else begin 
        print_string "Invalid command. Your input cannot be parsed.\n";
        print_endline "Please try again with a new command.\n";
        print_string  "> ";
        match read_line () with
        | exception End_of_file -> ()
        | new_cmd -> read_and_exc st new_cmd bot_on bot_difficulty display_on
      end
    end

  (* Reports error in command with respect to the game rules to the player, 
     and prompts for a new command. *)
  | Rules.Illegal msg -> begin
      print_string ("Illegal command: "^ msg ^"\n");
      print_endline "Please try again with a new command.\n";
      print_string  "> ";
      (*Graphics Display*)
      if display_on then begin
        Display.display_msg st ("Illegal command: "^ msg ^"\n");
        let next_cmd = Display.read_actions () in 
        read_and_exc st next_cmd bot_on bot_difficulty display_on
      end 
      (*Terminal Mode*)
      else begin
        match read_line () with
        | exception End_of_file -> ()
        | new_cmd -> read_and_exc st new_cmd bot_on bot_difficulty display_on
      end
    end

(* Game modes *)
let normal = Yojson.Basic.from_file "./configs/normal.json"
let hard = Yojson.Basic.from_file "./configs/hard.json"
let short = Yojson.Basic.from_file "./configs/short.json"

(* [play_game f bot_on display_on] reads the game file [f], 
   and initializes state by calling [read_and_exc]. If [bot_on]
   is true, player 2 is a bot, otherwise player 2 is a human play.
   [bot_difficulty] is the selected difficulty of the bot, it
   is Random if the bot is off.
   If [display_on] is true, a graphics window is built, otherwise, 
   terminal graphics are used. *)
let play_game f bot_on bot_difficulty display_on= 
  let init_state = State.init_from_json f in
  let _ =
    if display_on then
      Display.init_window init_state
    else () 
  in

  if f = normal then read_and_exc init_state "start normal.json" bot_on 
      bot_difficulty display_on
  else if f = hard then read_and_exc init_state "start hard.json" bot_on 
      bot_difficulty display_on
  else read_and_exc init_state "start short.json" bot_on bot_difficulty
      display_on

(** [choose_display board bot_on] prompts the user to select a display
    mode to be passed onto [play_game].
    [board], [bot_on], and [bot_difficulty] are settings chosen previously. *)
let rec choose_display board bot_on bot_difficulty = 
  print_endline "\nWhat type of graphics would you like to play with?";
  print_string "1. X11 Window Graphics\n";
  print_string "2. Terminal/ASCII Graphics\n\n";
  print_string "Q. Quit\n\n";


  print_string  "> ";

  match read_line () with
  | exception End_of_file -> ()
  | "1" -> play_game board bot_on bot_difficulty true
  | "2" -> play_game board bot_on bot_difficulty false
  | "q" | "Q" -> exit 0;
  | _ -> print_endline 
           "Oh no! It looks like your input was wrong. Try again.\n";
    choose_display board bot_on bot_difficulty

let rec choose_difficulty board =
  print_endline "\nWhat level of difficulty bot would you like to play with?";
  print_string "1. Random\n";
  print_string "2. Naive\n";
  print_string "3. Smart\n\n";
  print_string "Q. Quit\n\n";
  print_string "Note: To advance the bot on it's turn, press any key \n\n";


  print_string  "> ";

  match read_line () with
  | exception End_of_file -> ()
  | "1" -> choose_display board true Random
  | "2" -> choose_display board true Naive
  | "3" -> choose_display board true Smart
  | "q" | "Q" -> exit 0;
  | _ -> print_endline 
           "Oh no! It looks like your input was wrong. Try again.\n";
    choose_difficulty board

(** [choose_p2 board] prompts the user to choose whether or not player 2 is
    a bot. [board] is the previously selected board for the game. *)
let rec choose_p2 board = 
  print_endline "\nIs player 2 a human or would you like to play with a bot?";
  print_string "1. Human\n";
  print_string "2. Bot\n\n";
  print_string "Q. Quit\n\n";


  print_string  "> ";
  match read_line () with
  | exception End_of_file -> ()
  | "1" -> choose_display board false Random
  | "2" -> choose_difficulty board
  | "q" | "Q" -> exit 0;
  | _ -> print_endline 
           "Oh no! It looks like your input was wrong. Try again.\n";
    choose_p2 board

(* [main ()] welcomes the player, prints a list of pre-created json game files  
   with short descriptions for each, prompts for a string input for the file of 
   the game to play, and calls [choose_p2] with the inputted file name to 
   prompt the user to select other settings and then start 
   the specified game. *)
let rec main () =
  ANSITerminal.(print_string [red]
                  "\n\nWelcome to the Royal Game of Ur!\n");
  print_string "Here are the games you can play:\n";
  print_string "1. Normal Game\n";
  print_string "2. Hard Game\n";
  print_string "3. Short Game\n\n";
  print_string "Q. Quit\n\n";

  print_endline "Please enter the number of the board type you want to load.\n";
  print_string  "> ";
  match read_line () with
  | exception End_of_file -> ()
  | "1" -> choose_p2 normal
  | "2" -> choose_p2 hard
  | "3" -> choose_p2 short
  | "q" | "Q" -> exit 0;
  | _ -> print_endline 
           "Oh no! It looks like your input was wrong. Try again.\n";
    main ()

(* Execute the game engine. *)
let () = main ()
