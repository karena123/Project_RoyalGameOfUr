open Yojson.Basic.Util
open Command

type turn =
  | P1
  | P2

type t = {
  board : Board.t;
  score_p1 : int;
  score_p2 : int;
  turn : turn;
  pieces_p1 : Piece.t list;
  pieces_p2 : Piece.t list;
  dice: Dice.t;
  roll: int option;
  winner: string option;
}

(********************************************************************
   Helper functions.
 ********************************************************************)

(** [unplayed board lst] is a helper function for [get_P1_pieces] and 
    [get_P2_pieces].
    Returns a list of unplayed pieces for the player by iterating through a list 
    of all pieces the player has and seeing if each piece can be found on the 
    board and has not yet reached the exit tile. 
    If there are no pieces, an empty list is returned. 
    If a piece cannot be found on the board and has not reached the exit tile, 
    it is added to the unplayed pieces list for the player. *)
let rec unplayed board lst =
  match lst with
  | [] -> []
  | h :: t -> begin
      match Board.find_piece board h with
      | None -> h :: unplayed board t 
      | Some _ -> unplayed board t
    end 

(** [make_pieces_list is_p1 n] is the list of pieces enumerated from 1 to 
    [n]. *)
let make_pieces_list is_p1 n= 
  let rec helper i res = 
    if i = 0 then res
    else helper (i - 1) (Piece.make_piece is_p1 i :: res)
  in 
  helper n []

(********************************************************************
   Main functions.
 ********************************************************************)

let get_board st =
  st.board

let get_P1_pieces st =
  unplayed st.board st.pieces_p1

let get_P2_pieces st =
  unplayed st.board st.pieces_p2

let score_of_P1 st =
  st.score_p1

let score_of_P2 st =
  st.score_p2

let get_turn st =
  st.turn  

let get_roll st =
  st.roll

let create_state board score1 score2 turn pieces1 pieces2 dice= {
  board = board;
  score_p1 = score1;
  score_p2 = score2;
  turn = turn;
  pieces_p1 = pieces1;
  pieces_p2 = pieces2;
  dice = dice;
  roll = None;
  winner = None;
}

let init_from_json j = 
  let piece_count = j |> member "piece_count" |> to_int in 
  let board = Board.from_json j in 
  let dice = Dice.from_json j in 
  let pieces1 = make_pieces_list true piece_count in 
  let pieces2 = make_pieces_list false piece_count in 
  create_state board 0 0 P1 pieces1 pieces2 dice

(** [roll st] represents the current dice roll. *)
let roll st = 
  {st with roll = Some (Dice.roll st.dice |> Dice.sum)}

(** [toggle_turn st] changes who the next player is based on the current player. 
    If it is currently player 1, then next is player 2's turn; vice versa. *)
let toggle_turn st = 
  let next = match st.turn with 
    | P1 -> P2 
    | P2 -> P1 
  in 
  {st with turn = next}

(** [reset_roll st] resets the roll after a player has made a move so that the 
    next roll is ready to be made again. *)
let reset_roll st = 
  {st with roll = None}

(** [end_remove st t] removes pieces that have reached the end tile from the 
    game board. *)
let end_remove st t = 
  match Tile.remove_piece t with 
  | None -> failwith "Attempted to remove a piece from end, but no piece was found."
  | Some p -> begin 
      let lst = match st.turn with 
        | P1 -> st.pieces_p1 
        | P2 -> st.pieces_p2
      in 
      let new_lst = List.filter (fun x -> x <> p) lst in
      let has_winner = new_lst = [] in
      match st.turn with 
      | P1 when has_winner -> {st with pieces_p1 = new_lst;
                                       winner = Some "Player 1"}
      | P2 when has_winner -> {st with pieces_p2 = new_lst; 
                                       winner = Some "Player 2"}
      | P1 -> {st with pieces_p1 = new_lst}
      | P2 -> {st with pieces_p2 = new_lst}
    end 

(** [move_piece st p r] represents the moved piece in the current state. *)
let move_piece st p r = 
  let _ = match Board.find_piece st.board p with 
    | None -> Board.add_piece_board st.board p r; st
    | Some _ -> Board.move_piece st.board p r; st
  in
  match Board.find_piece st.board p with 
  | None -> failwith "Piece was moved but destination tile could not be found."
  | Some dest -> begin 
      match Tile.get_type dest with 
      | Tile.Rosetta -> st |> reset_roll
      | Tile.End -> 
        let new_st = end_remove st dest |> toggle_turn |> reset_roll in
        if st.turn = P1 then {new_st with score_p1 = st.score_p1 + 1} 
        else {new_st with score_p2 = st.score_p2 + 1}
      | Tile.MidEnd -> toggle_turn st |> reset_roll
      | Tile.Normal -> toggle_turn st |> reset_roll
    end

let update_state cmd st = 
  match cmd with 
  | Roll -> roll st
  | Move {piece= p; roll= r} -> move_piece st p r
  | Pass -> toggle_turn st |> reset_roll
  | Quit -> print_string "See you later!\n"; exit 0
  | Start str ->  "./configs/" ^ str |> Yojson.Basic.from_file |> init_from_json

let get_winner st = 
  st.winner
