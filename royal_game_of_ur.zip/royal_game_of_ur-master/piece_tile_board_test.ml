(** This is the Piece_Tile_Board test file. There are a total of 23 passing 
    tests.

    Parts of the system that were automatically tested by OUnit include: 
    Making and getting different Player 1 and Player 2 pieces, getting game 
    board tile types, getting pieces on the board, checking the current tile 
    the current moved piece is on, checking whether the moved piece is on the 
    End tile or on a Rosetta tile, checking the next tile, checking the path 
    length on the board to ensure that the paths have the same length as 
    expected based on the json configurations, and checking the partial path 
    lengths to ensure that the board was correctly formatted according to the 
    json configuration.

    Parts of the system that were manually tested include: None.

    How test cases were developed: Test cases were developed using black box 
    testing to test that the modules' functions were working in general as 
    expected, to test basic boundaries of the functions, and to check that 
    game boards, pieces, and tiles were made according to specific json 
    configurations.

    Why the testing approach demonstrates the correctness of the system: 
    Black box testing was used because we cannot test exactly all possible 
    types of json configurations to make the boards, the pieces, and tiles; 
    however, we were able to test general game inputs that seem likely and/or 
    common. Since all tests have passed, this suggests that our module 
    implementations are correct.
*)

open OUnit2
open Tile
open Piece
open Board

let p1_piece = Piece.make_piece true 1 
let p2_piece = Piece.make_piece false 5

(** [string_of_piece piece] creates a string representation of
    [piece] with the player designation of the piece followed by the
    number of the piece *)
let string_of_piece= function
  | P1 x -> "P1 "^ string_of_int x
  | P2 x -> "P2 "^ string_of_int x

(** [string_of_piece_opt piece] creates a string representation of piece 
    option [piece] with the player designation of the piece followed by the
    number of the piece *)
let string_of_piece_opt = function
  | None -> "None"
  | Some piece -> begin
      match piece with
      |P1 x -> "P1 "^ string_of_int x
      |P2 x -> "P2 "^ string_of_int x
    end

(** [string_of_tile_opt tile] creates a string representation of a tile
    option [tile], printing the type of the tile and the piece inside
    it. *)
let string_of_tile_opt = function
  | None -> "None"
  | Some tile -> begin
      match get_type tile with
      | End -> "[End]"
      | Normal -> "[Normal " ^ string_of_piece_opt (get_piece tile) ^"]"
      | Rosetta -> "[Rosetta " ^ string_of_piece_opt (get_piece tile) ^"]"
      | MidEnd -> "[MidEnd " ^ string_of_piece_opt (get_piece tile) ^"]"
    end

(** [string_of_board board] creates a string representation of a board,
    printing the tiles of player 1's path followed by the tiles
    of player 2's path. *)
let string_of_board board = 
  let rec string_of_path tile_opt is_p1 =
    match tile_opt with
    | None -> string_of_tile_opt tile_opt
    | Some tile -> string_of_tile_opt tile_opt ^ 
                   string_of_path (next_tile tile is_p1) is_p1
  in
  "P1: " ^ string_of_path (Some (path_start board true)) true ^ "P2: " ^
  string_of_path (Some (path_start board false)) false

(** [is_p1_test name piece bool] creates an OUnit2 test [name] that
    tests that is_p1 [piece] is equal to [bool] *)
let is_p1_test name piece bool =
  name >:: (fun _ -> 
      piece |> is_p1 |> assert_equal bool )

(** [get_num_test name piece num] creates an OUnit2 test [name] that
    tests that get_num [piece] is equal to [num] *)
let get_num_test name piece num = 
  name >:: (fun _ ->
      piece |> get_num |> assert_equal num )

(** [get_type_test name tile tile_type] creats an OUnit2 test [name]
    that checks that get_type [tile] is equal to [tile_type] *)
let get_type_test name tile tile_type =
  name >:: (fun _ ->
      tile |> get_type |> assert_equal tile_type)

(** [get_piece_test name tile piece_opt] creates an OUnit2 test [name]
    that checks that get_piece [tile] is [piece_opt] *)

let get_piece_test name tile piece_opt =
  name >::  (fun _ ->
      tile |> get_piece |> assert_equal piece_opt)

(** [is_rosetta_test name tile bool]  creates an OUnit2 test [name]
    that checks that is_rosetta [tile] is [bool]*)
let is_rosetta_test name tile bool = 
  name >::  (fun _ ->
      tile |> is_rosetta |> assert_equal bool)

(** [is_end_test name tile bool]  creates an OUnit2 test [name]
    that checks that is_end [tile] is [bool]. *)
let is_end_test name tile bool = 
  name >::  (fun _ ->
      tile |> is_end |> assert_equal bool)

(** [next_tile_test name is_p1 tile next] creates an OUnit2 test
    [name] that checks that next_tile [is_p1] [tile] is [next],
    whcih should be an option. *)
let next_tile_test name tile is_p1 next =
  name >:: (fun _ ->
      next_tile tile is_p1 |> assert_equal next)

(********************************************************************
   End helper functions.
 ********************************************************************)

let rosetta = create_tile Tile.Rosetta (Some p1_piece) 
let end_tile = create_tile Tile.End None
let normal = create_tile Tile.Normal None 
let midend = create_tile Tile.MidEnd None 

let rosetta_empty = remove_piece rosetta
let rosetta_full = add_piece rosetta p1_piece
let rosetta_full2 = add_piece rosetta p2_piece

let rosetta_next = link_next rosetta true normal
let link_end = link_next end_tile true normal
let midend2 = link_next midend true normal 
let midend3 = link_next midend false rosetta

(********************************************************************
   End Data.
 ********************************************************************)

let piece_tests = [
  "Invalid Num" >:: (fun _ ->
      (fun () -> Piece.make_piece true ~-1) |> 
      assert_raises (InvalidNum ~-1));

  is_p1_test "P1 piece is_p1" p1_piece true;
  is_p1_test "P2 piece is_p1" p2_piece false;
  get_num_test "P1 piece get_num" p1_piece 1;
  get_num_test "P2 piece get_num" p2_piece 5;
]

let tile_tests = [
  get_type_test "rosetta get_type" rosetta Rosetta;
  get_type_test "normal get_type" normal Normal;
  get_type_test "end_tile get_type" end_tile End;
  get_type_test "midend get_type" midend MidEnd;

  get_piece_test "Rosetta_full2 get_piece" rosetta (Some p2_piece);
  get_piece_test "end_tile get_piece" end_tile None;

  is_rosetta_test "Rosetta is_rosetta" rosetta true;
  is_rosetta_test "normal is_rosetta" normal false;

  is_end_test "End is_end" end_tile true;
  is_end_test "Normal is_end" normal false;

  next_tile_test "Rosetta_next next_tile" rosetta false (Some normal);
  next_tile_test "End next_tile" end_tile true None;

  next_tile_test "MidEnd3 next p1" midend true (Some normal);
  next_tile_test "MidEnd3 next p2" midend false (Some rosetta);
]

let normal_board = Yojson.Basic.from_file "./configs/normal.json" |> from_json 
let hard_board = Yojson.Basic.from_file "./configs/hard.json" |> from_json 

(** [path_length_tests name board length] creates and OUnit2 test case [name] 
    that checks that path length in [board] is the same as [length]  *)
let path_length_test name board length =
  name >:: (fun _ -> assert_equal length (Board.path_length board))

(** [path_length_tests name board partial_length] creates and OUnit2 test case 
    [name] that checks that path length in [board] is the same as 
    [partial_lengths]  *)
let partial_path_length_test name board partial_lengths =
  name >:: (fun _ -> assert_equal partial_lengths 
               (Board.get_partial_path_lengths board))


let board_tests = [
  path_length_test "normal path length" normal_board 14;
  path_length_test "hard path length" hard_board 20;

  partial_path_length_test "normal partial lengths" normal_board (4,8,2);
  partial_path_length_test "hard partial lengths" hard_board (6,10,4);
]

