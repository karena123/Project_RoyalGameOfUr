open Yojson.Basic.Util

(** [ascii_printer] contains useful functions for printing, including
    lists of various types and the game board itself. *)

(** [print_board board] creates a matrix of pairs, containing
    single character strings and an ANSITerminal color
    essentially a character matrix where each character has a color, 
    that forming a visual representation of a board and prints it. *)
let print_board board  =

  (** [string_of_board board] creates a string representation of a board,
      printing the tiles of player 1's path followed by the tiles
      of player 2's path. *) 
  let start_length, mid_lenth, end_length =
    match Board.get_partial_path_lengths board with
    | (s,m,e) -> s, m, e 
  in

  let char_matrix = Array.make_matrix 22 ((mid_lenth * 12) + 4) 
      (" ", ANSITerminal.Black)  in
  (*  Creates a white border around the board. *)
  for j = 0 to (mid_lenth * 12) + 3 do
    char_matrix.(0).(j) <- ("=", ANSITerminal.White);
    char_matrix.(21).(j) <- ("=", ANSITerminal.White)
  done;
  for i = 0 to 21 do
    char_matrix.(i).(0) <- ("|", ANSITerminal.White);
    char_matrix.(i).((mid_lenth * 12) + 3) <- ("|", ANSITerminal.White)
  done;

  (** [add_tile tile_char piece_opt row col color box] creates a tile
      represented in the character matrix. [tile_char] is the identifier
      to be printed on the tile, i.e. '*' if it is a rosetta tile. 

      [piece_opt] is a piece option for that tile, that, if some,
      is added to the tile represnetation in the character matrix.

      [row] and [col] are the "coordinates" of the
      upper left location of the tile being added to
      the character matrix.

      [color] is the ANSITerminal color of this tile. 

      [box] is 4-tuple that is of the form (wall_l, wallr_r, roof, floor)
      where each representes the character that will be used to create that
      tile in the character matrix. *)
  let rec add_tile tile_char piece_opt row col color box =
    let wall_l, wall_r, roof, floor =  
      match box with
      | (wl, wr, r, f) -> wl, wr, r, f 
    in
    (** [draw_empty_tile r c] adds the characters needed for a tile
        with no piece on it, [r] is the row of the upper left character
        being added and [c] is the coloumn. *)
    let draw_empty_tile r c =
      for i = r to r + 5 do 
        char_matrix.(i).(c) <- (wall_l, color);
        char_matrix.(i).(c + 11) <- (wall_r, color)
      done;
      for j = c to c + 11 do 
        char_matrix.(r).(j) <- (roof, color);
        char_matrix.(r + 5).(j) <- (floor, color)
      done;
      char_matrix.(r + 2).(c + 5) <- (tile_char, color) 
    in 
    (** [draw_piece_tile r c piece] adds a character for a tile
        with piece [piece]. [r] is the row of the upper left
        character  of the tile being added 
        and [c] is the coloumn. *)
    let draw_piece_tile r c piece= 
      draw_empty_tile r c;
      let color_p = if Piece.is_p1 piece then ANSITerminal.Cyan 
        else ANSITerminal.Red 
      in
      char_matrix.(r + 3).(c + 4) <- ("P", color_p);
      char_matrix.(r + 3).(c + 5) 
      <- (if Piece.is_p1 piece then ("1", color_p) else ("2", color_p));  
      char_matrix.(r + 3).(c + 7) 
      <- ((piece |> Piece.get_num |> string_of_int), color_p)

    in
    match piece_opt with 
    | Some piece -> draw_piece_tile row col piece
    | None -> draw_empty_tile row col
  in
  (** [follow_path_end tile_opt is_p1 row col color] creates the tiles
      along the end of a path from [tile_opt]. [is_p1] is true if
      the path is player 1's, false otherwise, [row] and [col] are
      the row and col that the upperleft of the current tile will be added
      to and [color] is the color of the tile. *)
  let rec follow_path_end tile_opt is_p1 row col color =
    match tile_opt with 
    | None -> ()
    | Some tile ->
      match Tile.get_type tile with 
      | End -> add_tile "E" (Tile.get_piece tile) row col color 
                 ("|", "<", "=", "="); 
        follow_path_end (Tile.next_tile tile is_p1) is_p1 row (col - 12) color
      | _ -> add_tile " " (Tile.get_piece tile) row col color 
               ("<", "<", "=", "="); ; 
        follow_path_end (Tile.next_tile tile is_p1) is_p1 row (col - 12) color
  in 

  (** [follow_path_middle tile_opt is_p1 row col color] creates the tiles
      along the end of a middle from [tile_opt]. [is_p1] is true if
      the path is player 1's, false otherwise, [row] and [col] are
      the row and col that the upperleft of the current tile will be added
      to and [color] is the color of the tile, although the tile themselves
      will be green rather than [color]. *)
  let rec follow_path_middle tile_opt is_p1 col color=
    match tile_opt with 
    | None -> ()
    | Some tile ->
      match Tile.get_type tile with 
      | Rosetta -> add_tile "*" (Tile.get_piece tile) 8 col ANSITerminal.Green
                     (">", ">", "=", "="); 
        follow_path_middle (Tile.next_tile tile is_p1) is_p1 (col + 12) color
      | Normal -> add_tile " " (Tile.get_piece tile) 8 col ANSITerminal.Green
                    (">", ">", "=", "=");
        follow_path_middle (Tile.next_tile tile is_p1) is_p1 (col + 12) color
      | MidEnd -> add_tile " " (Tile.get_piece tile) 8 col ANSITerminal.Green
                    (">", "|", "\\", "/"); 
        let r = if is_p1 then 14 else 2 in
        follow_path_end (Tile.next_tile tile is_p1) is_p1 r (col) color
      | _ -> ()

  in

  (** [follow_path_start tile_opt is_p1 row col color] creates the tiles
      along the start of a path from [tile_opt]. [is_p1] is true if
      the path is player 1's, false otherwise, [row] and [col] are
      the row and col that the upperleft of the current tile will be added
      to and [color] is the color of the tile. *)
  let rec follow_path_start tile_opt is_p1 row col color =
    match tile_opt with 
    | None -> ()
    | Some tile -> 
      match Tile.get_type tile with 
      | Rosetta -> 
        if is_p1 then begin
          add_tile "*" (Tile.get_piece tile) row col color 
            ("|", "<", "/", "=");
          follow_path_middle (Tile.next_tile tile is_p1) is_p1 (col) color end 
        else begin
          add_tile "*" (Tile.get_piece tile) row col color 
            ("|", "<", "=", "\\" );
          follow_path_middle (Tile.next_tile tile is_p1) is_p1 (col) color
        end
      | _ -> add_tile " " (Tile.get_piece tile) row col color 
               ("<", "<", "=", "="); 
        follow_path_start (Tile.next_tile tile is_p1) is_p1 row (col - 12) color
  in

  let start1 = Board.path_start board true in
  let start2 = Board.path_start board false in
  add_tile "S" (Tile.get_piece start2) 2 (((start_length - 1) * 12) + 2)
    ANSITerminal.Red ("<", "|", "=", "=");
  add_tile "S"(Tile.get_piece start1) 14 (((start_length - 1) * 12) + 2) 
    ANSITerminal.Cyan ("<", "|", "=", "=");
  follow_path_start (Tile.next_tile start2 false) false 2 (
    ((start_length-2) * 12) + 2)  ANSITerminal.Red;
  follow_path_start (Tile.next_tile start1 true) true 14 
    (((start_length-2) * 12) + 2) ANSITerminal.Cyan;

  (** [pair_print pair] takes in a pair from the character mattrix [pair]
      and prints it using the character and the color stored in the pair. *)
  let pair_print = function
    | (str, ANSITerminal.Red) -> 
      ANSITerminal.(print_string [red; on_black] str);
    | (str, ANSITerminal.Cyan) -> 
      ANSITerminal.(print_string [cyan; on_black] str);
    | (str, ANSITerminal.Green) -> 
      ANSITerminal.(print_string [green; on_black] str);
    | (str, _) -> ANSITerminal.(print_string [white; on_black] str);
  in

  Array.iter (fun row -> (Array.iter pair_print row); print_newline ()) 
    char_matrix

(** [string_of_piece piece] creates a string representation of
    [piece] with the player designation of the piece followed by the
    number of the piece. *)
let string_of_piece= function
  | Piece.P1 x -> string_of_int x
  | Piece.P2 x -> string_of_int x

let rec string_of_list stringify res lst = 
  match lst with 
  | [] -> res 
  | h :: t -> string_of_list stringify (stringify h ^ "; " ^ res) t

let string_of_turn = function 
  | State.P1 -> "P1" 
  | State.P2 -> "P2"

let string_of_int_opt = function 
  | None -> "None"
  | Some x -> string_of_int x

let print_state st = 
  print_board (State.get_board st);
  let rest = "\n\nNext to move: \n"
             ^ string_of_turn (State.get_turn st)
             ^ "\n\nCurrent roll: \n"
             ^ string_of_int_opt (State.get_roll st)
             ^ "\n\nScore: \n" 
             ^ string_of_int (State.score_of_P1 st)
             ^ " - "
             ^ string_of_int (State.score_of_P2 st)
             ^ "\n\nP1 pieces in hand: \n"
             ^ string_of_list string_of_piece "" (State.get_P1_pieces st)
             ^ "\nP2 pieces in hand: \n"
             ^ string_of_list string_of_piece "" (State.get_P2_pieces st)
             ^ "\n"
             (* ^ "\n\nP1 pieces in hand: \n"
                ^ string_of_list string_of_piece "" (st.pieces_p1)
                ^ "\nP2 pieces in hand: \n"
                ^ string_of_list string_of_piece "" (st.pieces_p2)
                ^ "\n" *)
  in 
  print_string(rest);